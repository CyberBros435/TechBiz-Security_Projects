# TechBiz Security — SOC Analyst Internship
## Week 1 · Task 1 — Cyber Security Introduction & What is a SOC?

**Internship Track:** SOC Analyst  
**Task:** Week 1 — Task 1  
**Submission Date:** 20 August 2026  
**Practical Evidence:** TryHackMe + CyberDefenders research  
**Status:** Completed

---

## 1. Objective

The objective of this task was to establish foundational SOC analyst knowledge by studying core information-security principles, understanding the role of a Security Operations Center (SOC), differentiating analyst tiers, and understanding the responsibilities of defensive and offensive security teams.

The practical component was completed through the free TryHackMe rooms **Security Principles** and **Pentesting Fundamentals**, supported by research into SOC analyst responsibilities.

---

## 2. CIA Triad

The CIA Triad is a foundational information-security model consisting of **Confidentiality, Integrity, and Availability**.

| Principle | Meaning | Security Example |
|---|---|---|
| **Confidentiality** | Ensures information is accessible only to authorized users. | Access controls and encryption prevent unauthorized disclosure of sensitive data. |
| **Integrity** | Ensures information remains accurate, trustworthy, and protected from unauthorized modification. | Hashing and file-integrity controls can detect unauthorized changes. |
| **Availability** | Ensures systems and information remain accessible when authorized users need them. | Redundancy, backups, monitoring, and recovery controls help maintain service availability. |

### Practical Learning

The Security Principles room included direct exercises involving the CIA Triad and security principles. The completed-room screenshots are included as evidence in this report.

---

## 3. Threat vs Vulnerability vs Risk

These three terms describe different parts of a security problem:

- **Threat:** An actor, event, or circumstance capable of causing harm.
- **Vulnerability:** A weakness that can be exploited by a threat.
- **Risk:** The potential for a threat to exploit a vulnerability and cause a negative business or technical impact.

### Example

**Scenario:** An internet-facing web application is running an outdated version.

- **Threat:** An attacker attempting to exploit the application.
- **Vulnerability:** The outdated application version.
- **Risk:** The attacker may exploit the weakness and compromise the application or underlying system, potentially causing unauthorized access or data loss.

This distinction is important for SOC analysts because alerts must be evaluated in terms of the threat, the underlying weakness, and the potential impact.

---

## 4. What is a Security Operations Center?

A **Security Operations Center (SOC)** is a dedicated security function responsible for continuously monitoring an organization's technology environment and detecting, investigating, and responding to security threats and incidents.

A SOC commonly works with:

- Security alerts and event logs
- Network and endpoint telemetry
- SIEM platforms
- EDR/XDR tools
- Threat intelligence
- Incident-response procedures
- Detection and monitoring rules

### Core SOC workflow

**Telemetry → Alert → Triage → Investigation → Containment/Response → Recovery → Lessons Learned**

The purpose of a SOC is not simply to watch dashboards. Its practical goal is to turn security telemetry into timely decisions: determine whether an alert is legitimate, understand its scope and impact, contain threats when required, and escalate incidents appropriately.

---

## 5. SOC Analyst Levels

| Level | Typical Responsibilities |
|---|---|
| **L1 — Tier 1** | Monitor alerts, perform initial triage, validate suspicious activity, collect basic evidence, document findings, and escalate confirmed or complex incidents. |
| **L2 — Tier 2** | Conduct deeper investigations, correlate multiple logs/events, determine scope and impact, investigate suspicious hosts/users, and manage incidents escalated by L1. |
| **L3 — Tier 3** | Handle advanced investigations, complex incident response, threat hunting, malware/deep technical analysis, detection engineering, and high-level escalations. |

### Escalation Model

**L1 detection & triage → L2 investigation → L3 advanced analysis**

The exact responsibilities vary between organizations, but the escalation model provides a practical way to understand increasing technical depth and incident complexity.

---

## 6. Blue Team vs Red Team

| Blue Team | Red Team |
|---|---|
| Defensive security function | Offensive security function |
| Monitors and protects systems | Simulates authorized attacks |
| Detects and investigates threats | Finds and demonstrates weaknesses |
| Performs incident response | Tests defensive controls |
| Improves detection and resilience | Measures how effectively defenses withstand attack |

Both teams contribute to organizational security. The Red Team identifies weaknesses through authorized adversarial testing, while the Blue Team detects, investigates, responds to, and improves defenses against those techniques.

---

## 7. Practical Work Completed

### TryHackMe — Security Principles

The **Security Principles** room was completed. The exercises covered foundational security concepts and included practical interaction with concepts such as the CIA Triad.

**Evidence:** `security1.png` through `security7.png`

![Security Principles — Room](security1.png)

![Security Principles — Practical Exercise](security2.png)

![Security Principles — CIA Triad Exercise](security3.png)

![Security Principles — Completed Exercise](security4.png)

![Security Principles — Model Exercise](security5.png)

![Security Principles — Completed Questions](security6.png)

![Security Principles — Additional Evidence](security7.png)

---

### TryHackMe — Pentesting Fundamentals

The **Pentesting Fundamentals** room was previously completed and was re-verified for this internship task. Screenshots were captured as completion/practical evidence.

**Evidence:** `pentest1.png` through `pentest3.png`

![Pentesting Fundamentals — Room](pentest1.png)

![Pentesting Fundamentals — Practical Content](pentest2.png)

![Pentesting Fundamentals — Completion Evidence](pentest3.png)

---

### SOC Analyst Research — CyberDefenders

Research was performed on SOC analyst responsibilities using CyberDefenders material. The research reinforced the role of a SOC analyst as a frontline defensive function responsible for monitoring, detecting, investigating, and responding to security threats.

**Evidence:** `soc1.png` and `soc2.png`

![SOC Analyst Research](soc1.png)

![CIA Triad Research](soc2.png)

---

## 8. Key Learning Outcomes

After completing the task, the following concepts were covered:

1. The three components of the CIA Triad.
2. The difference between a threat, vulnerability, and risk.
3. The purpose and operational workflow of a SOC.
4. The responsibilities of L1, L2, and L3 SOC analysts.
5. The difference between Blue Team and Red Team operations.
6. The relationship between security monitoring, alert triage, investigation, and escalation.
7. Practical exposure to foundational security concepts through TryHackMe.

---

## 9. Conclusion

Week 1 Task 1 established the foundational knowledge required for progressing toward SOC analyst work. The practical TryHackMe activities provided hands-on reinforcement of security principles and penetration-testing fundamentals, while SOC-focused research connected those concepts to defensive monitoring and incident operations.

The key operational lesson is that a SOC analyst must be able to distinguish normal activity from suspicious activity, understand why an event matters, gather relevant evidence, and escalate incidents according to their complexity and impact.

**Task Status: COMPLETED**

---

## Evidence Index

| Evidence | Purpose |
|---|---|
| `security1.png` | Security Principles room |
| `security2.png` | Security Principles practical section |
| `security3.png` | CIA Triad exercise |
| `security4.png` | Completed exercise evidence |
| `security5.png` | Security model exercise |
| `security6.png` | Additional completed questions |
| `security7.png` | Additional completion evidence |
| `pentest1.png` | Pentesting Fundamentals room |
| `pentest2.png` | Pentesting Fundamentals content |
| `pentest3.png` | Pentesting Fundamentals evidence |
| `soc1.png` | CyberDefenders SOC analyst research |
| `soc2.png` | CIA Triad research |
