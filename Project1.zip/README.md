# 🛡️ TechBiz Security — Cyber Security Internship Projects

![Cyber Security](https://img.shields.io/badge/Focus-Cyber%20Security-0f766e)
![SOC](https://img.shields.io/badge/Track-SOC%20Analyst-1d4ed8)
![Internship](https://img.shields.io/badge/Program-TechBiz%20Security-7c3aed)
![Status](https://img.shields.io/badge/Status-In%20Progress-f59e0b)

> A professional portfolio repository containing practical projects, reports, evidence, and learning outcomes completed during my **TechBiz Security SOC Analyst Internship**.

---

## 📌 About This Repository

This repository is the central project portfolio for my **TechBiz Security Internship**.

It is organized so that each internship task can be added without changing the overall repository structure. Every completed project can contain its own documentation, final report, practical evidence, screenshots, and supporting files.

The goal is to demonstrate **practical cybersecurity skills**, not just theoretical knowledge.

### Main areas covered

- 🔐 Cybersecurity fundamentals
- 🛡️ Security Operations Center (SOC)
- 📊 Security monitoring and analysis
- 🌐 Networking and network security
- 🔎 Reconnaissance and security assessment
- 🧪 Practical security labs
- 🖥️ Linux and security tools
- 📡 Wireshark and packet analysis
- 📋 Incident investigation and documentation
- 🧰 Python-based security projects
- 📑 Professional security reporting

---

# 📂 Repository Structure

```text
TechBiz-Security_Projects/
│
├── README.md
│
├── Week-01/
│   │
│   └── Task-01-Cybersecurity-Introduction-SOC/
│       ├── README.md
│       ├── Report.md
│       ├── Report.pdf
│       └── evidence/
│           ├── security1.png
│           ├── security2.png
│           ├── security3.png
│           ├── security4.png
│           ├── security5.png
│           ├── security6.png
│           ├── security7.png
│           ├── pentest1.png
│           ├── pentest2.png
│           ├── pentest3.png
│           ├── soc1.png
│           └── soc2.png
│
├── Week-01/
│   └── Task-02-...
│
├── Week-02/
│   └── Task-01-...
│
└── ...
```

> **Note:** The exact folder names may change as new internship tasks are completed. The principle remains the same: **one clearly separated folder per task/project**.

---

# 🚀 Internship Progress

| Week | Task | Project | Status |
|---|---|---|---|
| Week 01 | Task 01 | Cyber Security Introduction + What is a SOC? | ✅ Completed |
| Week 01 | Task 02 | Coming Soon | ⏳ Pending |
| Week 02 | Task 01 | Coming Soon | ⏳ Pending |
| Week 02 | Task 02 | Coming Soon | ⏳ Pending |

---

# 🧩 Project 01 — Cyber Security Introduction + What is a SOC?

### Week 1 · Task 1

**Status:** ✅ Completed

This project established the foundational knowledge required for SOC analyst work.

### Topics Covered

- CIA Triad
  - Confidentiality
  - Integrity
  - Availability
- Threat vs Vulnerability vs Risk
- Security Operations Center (SOC)
- SOC monitoring and incident workflow
- L1 SOC Analyst responsibilities
- L2 SOC Analyst responsibilities
- L3 SOC Analyst responsibilities
- Blue Team vs Red Team
- Basic security operations concepts

### Practical Work

The task included completion/re-verification of:

- TryHackMe — **Security Principles**
- TryHackMe — **Pentesting Fundamentals**
- SOC analyst research using CyberDefenders material

### Deliverables

- 📄 `Report.md`
- 📕 `Report.pdf`
- 📸 Practical screenshots/evidence

### Project Folder

`Week-01/Task-01-Cybersecurity-Introduction-SOC/`

---

# 📊 Evidence & Documentation

Each project is intended to contain evidence supporting the work actually performed.

Typical evidence can include:

- TryHackMe completion screenshots
- Tool screenshots
- Terminal output
- Wireshark captures
- SIEM dashboards
- Security investigation results
- Code execution screenshots
- Configuration screenshots
- Lab results
- Findings and observations

Screenshots are included to provide **verifiable practical evidence** rather than making unsupported claims about project completion.

---

# 📑 Documentation Standard

For larger tasks, project folders may contain:

```text
README.md
Report.md
Report.pdf
evidence/
screenshots/
src/
scripts/
logs/
```

Not every project will require every directory.

The structure will be kept proportional to the actual project so the repository remains clean and professional.

---

# 🎯 Skills Demonstrated

As the internship progresses, this repository will demonstrate practical experience in areas such as:

### Security Fundamentals

- CIA Triad
- Threats
- Vulnerabilities
- Risk
- Security controls
- Authentication and authorization
- Defensive security concepts

### SOC Operations

- Alert triage
- Security monitoring
- Log analysis
- Incident investigation
- Incident escalation
- SOC analyst workflow
- L1/L2/L3 responsibilities

### Network Security

- TCP/IP
- DNS
- HTTP/HTTPS
- TCP three-way handshake
- Packet analysis
- Network reconnaissance
- Wireshark

### Security Tools

Tools used throughout the internship may include:

- TryHackMe
- Wireshark
- Splunk
- Linux
- Python
- Nmap
- Security monitoring tools
- Other tools introduced during the internship

### Documentation

- Technical reports
- Investigation notes
- Evidence collection
- Security findings
- GitHub documentation
- Professional project presentation

---

# 🧪 Practical-First Approach

This repository focuses on **doing the work and documenting the evidence**.

For each project, the intended workflow is:

```text
Learn
  ↓
Perform Practical Task
  ↓
Collect Evidence
  ↓
Analyze Results
  ↓
Document Findings
  ↓
Create Professional Report
  ↓
Publish Project
```

This makes the repository more useful as a portfolio because each project demonstrates both **knowledge and execution**.

---

# 📁 How New Internship Projects Are Added

For every new internship task:

### 1. Create a dedicated project folder

Example:

```text
Week-02/
└── Task-01-Network-Traffic-Analysis/
```

### 2. Add the project documentation

```text
README.md
Report.md
Report.pdf
```

### 3. Add practical evidence

```text
evidence/
├── screenshot-01.png
├── screenshot-02.png
└── screenshot-03.png
```

### 4. Add project files when applicable

For example:

```text
src/
scripts/
logs/
captures/
```

### 5. Update this master README

The internship progress table will be updated as each task is completed.

---

# 📈 Portfolio Goal

The final repository will provide a chronological record of the internship and demonstrate progression from cybersecurity fundamentals toward more practical SOC and security-analysis work.

The objective is to finish the internship with a portfolio that clearly answers:

> **What did I learn? What did I actually do? What evidence proves it? What did I discover?**

---

# 🏆 Internship Completion

At the end of the internship, this repository should contain:

- Completed internship tasks
- Practical cybersecurity projects
- Evidence/screenshots
- Technical reports
- PDF documentation
- Relevant scripts/code
- Investigation results
- Security analysis
- Lessons learned

The repository will be continuously updated as new internship tasks are completed.

---

## 👤 Author

**Mudasir**

Cyber Security / SOC Analyst Internship Portfolio

---

## ⚠️ Disclaimer

All security testing and practical activities documented in this repository are intended for **authorized educational and internship environments only**.

Do not use security tools or techniques against systems, networks, accounts, or applications without explicit authorization.

---

## 📌 Repository Status

**TechBiz Security Internship — In Progress**

More projects and evidence will be added as the internship continues.
